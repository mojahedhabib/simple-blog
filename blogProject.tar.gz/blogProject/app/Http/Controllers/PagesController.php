<?php
namespace App\Http\Controllers;

use App\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;

class PagesController extends Controller {
    public function getIndex() {
        $posts = Post::orderBy('created_at')->limit(4)->get();
        return view('pages.welcome')->with('posts', $posts);
    }

    public function getAbout() {
        return view('pages.about');
    }

    public function  getContact() {
        return view('pages.contact');
    }

    public function postContact(Request $request) {
        $this->validate($request, array(
            'email' => 'required|email',
            'subject' => 'min:3',
            'message' => 'required|min:10'
        ));

        $data = array(
            'email' => $request->email,
            'subject' => $request->subject,
            'bodyMessage' =>$request->message
        );

        Mail::send('emails.contact', $data, function($message) use ($data){
            $message->from($data['email']);
            $message->to('mojahedhabib3@gmail.com');
            $message->subject($data['subject']);
        });

        Session::flash('success', 'Successfully sent message.');
        return redirect()->back();
    }
}

?>