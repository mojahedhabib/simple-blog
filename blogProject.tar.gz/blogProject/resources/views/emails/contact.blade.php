<h3>Messages:</h3>
<hr>
<p>From: {{$email}}</p>
<p>Subject: {{$subject}}</p>
<div>Message: {{$bodyMessage}}</div>