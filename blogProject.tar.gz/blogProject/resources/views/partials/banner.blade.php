<!--
<div class="row">
    <div class="col col-lg-12">

    </div><!--end of header .row
</div>
-->
@section('stylesheets')
    <link rel="stylesheet" href="css/style.css">
@endsection

<div class="jumbotron jumbotron-fluid"  style="background-image: url('images/banner-img.jpg'); background-repeat: no-repeat; background-size: cover; height: 100%; width: 100%;">
    <div class="container">
        <h1 class="display-4"style="color: #123c24;"><strong>Welcome to my blog!</strong></h1>
        <p class="lead"style="color: #123c24;"><strong>This is my sample laravel testing blog, please see my post everytime...</strong></p>
        <hr class="my-4">
        <a class="btn btn-primary btn-lg" href="#" role="button">See popular posts...</a>
    </div>
</div>