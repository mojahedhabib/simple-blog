<?php $__env->startSection('title', "| @$post->title"); ?>

<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="<?php echo e(url("css/style.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(url("css/post.css")); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                    <div class="card-body">
                    <h1 class="card-title"><?php echo e($post['title']); ?></h1>
                    <div class="row">
                        <i style="color: #1E90FF;"><small><strong>Published at <?php echo e(date('M j, Y h:ia', strtotime($post['created_at']))); ?></strong></small></i><br><br>
                        &nbsp;<h6>Tags:</h6>
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h6><span class="badge badge-secondary"><?php echo e($tag->name); ?></span></h6>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                     <div class="image">
                         <img src="<?php echo e(asset('images/'. $post->image)); ?>" alt="post-image">
                     </div>
                    <p><?php echo $post['body']; ?>}</p>
                    <hr>
                    <p>Posted In: <?php echo e($post->category['name']); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8 offset-md-2 mt-5">
            <div class="card">
                <div class="card-body">
                    <h3 class="comments-title"><span class="far fa-comment-dots"></span><?php echo e($post->comments()->count()); ?>&nbsp;Comments</h3>
                    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="comment">
                            <div class="author-info">
                                <img src="<?php echo e("https://www.gravatar.com/avatar/". md5(strtolower(trim($comment->email)))); ?>" class="author-image">
                                <div class="author-name">
                                   <h4> <?php echo e($comment->name); ?></h4>
                                   <p class="author-time"> <?php echo e(date('F nS, Y - G:iA', strtotime($comment->created_at))); ?></p>
                                </div>
                            </div>
                            <div class="comment-content">
                                <?php echo e($comment->comment); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div id="comment-form" class="offset-md-4 mt-5">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('comments.store', $post->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" name="name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" name="email">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="comment">Comment</label>
                                    <textarea name="comment" id="comment" cols="30" rows="10" class="form-control" placeholder="Write your comments here..."></textarea>

                                    <input type="submit" class="btn btn-primary" value="Add Comment" style="margin-top: 10px;">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>