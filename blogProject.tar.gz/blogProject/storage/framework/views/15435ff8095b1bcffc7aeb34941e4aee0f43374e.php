<?php $__env->startSection('title', '| Create New Post'); ?>

<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="<?php echo e(url("css/parsley.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(url("css/select2.min.css")); ?>">

    <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>

    <script>
        tinymce.init({
            selector:'textarea',
            plugins: 'link',
            menubar: false
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col offset-md-2">
            <div class="card">
                <div class="card-body">
                <h2>Create New Post</h2>
                <hr>
                    <form action="<?php echo e(route('post.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="title" class="bmd-label-floating">Title</label>
                        <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title')); ?>" required><br>

                        <label for="slug">Slug</label>
                        <input type="text" id="slug" name="slug" class="form-control" value="<?php echo e(old('slug')); ?>"><br>

                        <label for="category_id">Category</label>
                        <select class="form-control" name="category_id" id="category_id">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select><br>

                        <label for="tags">Tags</label>
                        <select class="form-control select2-selection--multiple" multiple="multiple" name="tags[]" id="tags" >
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select><br> <br>
                        <div class="form-group">
                            <label for="post-image"></label>
                            <input  class="form-control" type="file" name="post-image" id="post-image">
                        </div>

                        <label for="body">Post Body</label>
                        <textarea name="body" id="body" cols="30" rows="10" class="form-control"><?php echo e(old('body')); ?></textarea>
                        <br>
                        <input type="submit" class="btn btn-lg btn-primary" value="Submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(url("js/parsley.min.js")); ?>"></script>
    <script src="<?php echo e(url("js/select2.min.js")); ?>"></script>
    <script src="<?php echo e(url("js/select2.min.js")); ?>"></script>

    <script>
        $(".select2-selection--multiple").select2({
            maximumSelectionLength: 10
        });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>