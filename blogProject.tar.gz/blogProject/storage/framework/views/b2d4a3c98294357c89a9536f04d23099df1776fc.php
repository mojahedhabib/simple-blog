<?php $__env->startSection('title', '| Blog'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <h1 class="card-title">Blogs</h1>
                <hr>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <h2><?php echo e($post->title); ?></h2>
                            <p><i>Published:</i> <?php echo e(date('M j, Y', strtotime($post->created_at))); ?></p>
                            <p><?php echo e(strip_tags(substr($post->body, 0, 250))); ?> <?php echo e(strlen($post->body) > 50 ? '...' : ""); ?></p>
                            <a href="<?php echo e(route('blog.single', [$post->id])); ?>">  <?php echo method_field('GET'); ?> Read more...</a>
                        </div>
                    </div>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br><br>
                <div class="row">
                    <div class="col-md-12">
                        <div class="text-center pagination pagination-sm justify-content-center">
                            <?php echo $posts->links();; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>