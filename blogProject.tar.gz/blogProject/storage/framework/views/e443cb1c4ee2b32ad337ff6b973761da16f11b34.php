<h3>Messages:</h3>
<hr>
<p>From: <?php echo e($email); ?></p>
<p>Subject: <?php echo e($subject); ?></p>
<div>Message: <?php echo e($bodyMessage); ?></div>