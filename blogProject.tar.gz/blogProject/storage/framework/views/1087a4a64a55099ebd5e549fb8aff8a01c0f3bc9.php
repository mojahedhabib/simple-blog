<?php $__env->startSection('title', '| All Posts'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <h1 class="card-title">All Posts</h1>
                            </div>
                            <div class="col">
                                <a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary float-right mt-1  btn-raised" >+ New Post</a>
                            </div>
                        </div>

                        <table class="table table-hover">
                            <thead>
                                <th>#</th>
                                <th>id#</th>
                                <th>Title</th>
                                <th>Body</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($post->id); ?></td>
                                        <td><?php echo e($post->title); ?></td>
                                        <td><?php echo e(strip_tags(substr($post->body, 0, 50))); ?><?php echo e(strip_tags(strlen($post->body) > 50 ? "...": "")); ?></td>
                                        <td><?php echo e(date('M d, Y', strtotime($post->created_at))); ?></td>
                                         <div class="row">
                                                 <td>
                                                     <a href="<?php echo e(route('post.show', $post->id)); ?>" class="btn btn-info btn-sm">View</a>
                                                 </td>
                                                 <td>
                                                     <a href="<?php echo e(route('post.edit', $post->id)); ?>"class="btn btn-success btn-sm">Edit</a>
                                                 </td>
                                         </div>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="pagination pagination-sm justify-content-center mt-1">
                    <?php echo $posts->links();; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>