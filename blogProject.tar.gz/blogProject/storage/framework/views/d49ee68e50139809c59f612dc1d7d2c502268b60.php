<?php $__env->startSection('title', '|Edit Post'); ?>

<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="<?php echo e(url("css/select2.min.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row" style="margin-top: 10px;">
        <div class="col col-md-8">
            <form action="<?php echo e(route('post.update', array($post->id))); ?>" method="post">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <h1>Edit Post</h1>
                <hr>
                <label for="title">Title</label>
                <input type="text" id="title" name="title" class="form-control" value="<?php echo e($post->title); ?>">
                <br>
                <label for="slug">Slug</label>
                <input type="text" id="slug" name="slug" class="form-control" value="<?php echo e($post->slug); ?>">
                <br>
                <label for="category_id">Category</label>
                <select class="form-control" name="category_id" id="category_id" >
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"
                                <?php if($category->id === $post->category_id): ?> selected="'selected"
                                <?php endif; ?>>
                            <?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> <br>

                <label for="tags" >Tags</label>
                <select class="form-control select2-selection--multiple" multiple="multiple" name="tags[]" id="tags" >
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php if(in_array($tag->id, $tagids)): ?>
                            <option value="<?php echo e($tag->id); ?>" selected="true"> <?php echo e($tag->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($tag->id); ?>"> <?php echo e($tag->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> <br> <br>

                <label for="body">Post Body</label>
                <textarea name="body" id="body" cols="30" rows="10" class="form-control" ><?php echo e($post->body); ?></textarea>
               <!-- <input type="submit" value="Save Changes">-->

        </div>

        <div class="col-md-4" style="margin-top: 30px; ">
            <div class="card" style="background-color:#FFF8DC; ">
                <div class="card-body">
                    <div class="col col-md-12" style="margin-top: 10px; ">
                        <div class="row text-justify  justify-content-center">
                            <dt class="card-title">Created At: &nbsp;</dt>
                            <dd  class="card-text"> <?php echo e(date('M j, Y h:ia', strtotime($post->created_at))); ?></dd>
                        </div>
                    </div>

                    <div class="col col-md-12" style="margin-top: 10px;">
                        <div class="row text-justify  justify-content-center" style="position: center;">
                            <dt class="card-title">last Updated: &nbsp;</dt>
                            <dd class="card-text mb-0"><?php echo e(date('M j, Y h:ia', strtotime($post->updated_at))); ?></dd>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                            <div class="col-sm-5 offset-md-1">
                                <form action="">
                                    <input type="submit"  class="btn btn-success btn-block" value="Save">
                                </form>

                            </div>

                            <div class="col-sm-5" style="">
                                <form action="<?php echo e(route('post.show', array($post->id))); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('GET'); ?>
                                    <input type="submit" value="Cancel" class="btn btn-block btn-primary">
                                </form>
                            </div>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url("js/select2.min.js")); ?>"></script>
    <script>
        $(".select2-selection--multiple").select2({
            maximumSelectionLength: 10
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>