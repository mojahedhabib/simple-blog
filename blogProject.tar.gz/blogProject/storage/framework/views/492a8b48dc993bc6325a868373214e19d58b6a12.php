<?php $__env->startSection('title', '| Homepage'); ?>
<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .jumbotron {
            background-image: url('images/jumbotron.jpg');
            background-repeat: no-repeat;
            background-size: cover; height: 100%;
            width: 100%;
            background-size: 100% 100%;
            background-position: center center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4"style="color: yellowgreen; font-size: 75px; text-decoration-color: darkblue;"><strong>Welcome to my blog!</strong></h1>
            <h2 class="lead" style="color:white;"><strong>This is my sample laravel testing blog, please see my post everytime...</strong></h2>
            <hr class="my-4">
            <a class="btn btn-primary btn-lg border-white" href="#" role="button">See popular posts...</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
        <div class="row float-lg-none mt-5">
                <div class="col col-md-8">
                    <h3 class="text-center">Hot Topics</h3>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card mb-3">
                            <img class="card-img-top" src="<?php echo e(asset('images/' . $post->image)); ?>" width="100px" height="300px" alt="images/jumbotron.jpg">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($post->title); ?></h5>
                                <p class="card-text"><?php echo e(strip_tags(substr($post->body, 0, 200))); ?> <?php echo e(strip_tags(strlen($post->body) > 300 ? "..." : "")); ?></p>
                                <a href="<?php echo e(route('blog.single', [$post->id])); ?>" class="btn btn-primary mb-3">Read more...</a>
                                <?php if(Auth::check()): ?>
                                    <div class="author-info">
                                        <img src="<?php echo e("https://www.gravatar.com/avatar/". md5(strtolower(trim(Auth::user()->email)))); ?>" class="author-image">
                                        <div class="author-name">
                                            <h5> <?php echo e(Auth::user()->name); ?></h5>
                                            <p class="author-time mb-0"> <?php echo e(date('M j, Y h:ia', strtotime($post['created_at']))); ?></p>
                                        </div>
                                    </div>


                                    <?php else: ?>
                                    <i style="
                                         font-size: 15px;
                                         font-style: italic;
                                         color: #aaa;">
                                        <small>
                                            <strong>Published at <?php echo e(date('M j, Y h:ia', strtotime($post['created_at']))); ?></strong>
                                        </small></i><br><br>
                                <?php endif; ?>
                                <div class="row float-right" style="margin-top: 40px; margin-right: 75px;">
                                    <p class="fas fa-tags"> Tags:</p>
                                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-secondary"><?php echo e($tag->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="row float-right mb-0">
                                    <div class="viewers">
                                        <span class="badge badge-info"><i class="fas fa-eye border-secondary mr-2"> 1032 views</i></span>
                                        <span class="badge badge-info"><i class="far fa-thumbs-up border-secondary mr-2"> 1032 views</i></span>
                                        <span class="badge badge-info"><i class="far fa-comments border-secondary mr-2"> 1032 views</i></span>
                                    </div>
                                </div>

                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><hr>

                <div class="col-md-4">
                    <h3 class="text-center mt-5">LATEST POSTS</h3>
                    <div class="card  ">
                        <div class="card-body">
                            <ul class="list-group">

                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Cras justo odio
                                    <span class="badge badge-primary badge-pill">14 views</span>
                                    <span class="badge badge-primary badge-pill">14 likes</span>
                                    <span class="badge badge-primary badge-pill">14 comments</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Cras justo odio
                                    <span class="badge badge-primary badge-pill">14 views</span>
                                    <span class="badge badge-primary badge-pill">14 likes</span>
                                    <span class="badge badge-primary badge-pill">14 comments</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <p class="card-title"></p>Morbi leo risus
                                    <span class="badge badge-primary badge-pill">14 views</span>
                                    <span class="badge badge-primary badge-pill">14 likes</span>
                                    <span class="badge badge-primary badge-pill">14 comments</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                   <p class="card-title"></p> Morbi leo risus
                                    <span class="badge badge-primary badge-pill">14 views</span>
                                    <span class="badge badge-primary badge-pill">14 likes</span>
                                    <span class="badge badge-primary badge-pill">14 comments</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Morbi leo risus
                                    <span class="badge badge-primary badge-pill">14 views</span>
                                    <span class="badge badge-primary badge-pill">14 likes</span>
                                    <span class="badge badge-primary badge-pill">14 comments</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                   <p class="card-title"> Morbi leo risus   Dapibus ac facilisis in   Cras justo odio </p>
                                    <span class="badge badge-primary badge-pill">14 views</span>
                                    <span class="badge badge-primary badge-pill">14 likes</span>
                                    <span class="badge badge-primary badge-pill">14 comments</span>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="card mt-5">
                        <div class="card-body">
                            <div class="list-group">
                                <h3 class="text-center">CATEGORIES</h3>
                                <ul class="list-group">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Cras justo odio
                                        <span class="badge badge-primary badge-pill">3 posts</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Dapibus ac facilisis in   Cras justo odio
                                        <span class="badge badge-primary badge-pill">2 posts</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Morbi leo risus
                                        <span class="badge badge-primary badge-pill">5 posts</span>
                                    </li>
                                </ul>
                            </div>
                            <h3 class="text-center">TAGS</h3>
                               <span class="badge badge-secondary">ularised in the 1960s with the rele</span>
                                <span class="badge badge-secondary">f Letraset sheets con</span>
                                <span class="badge badge-secondary">the release of</span>
                                <span class="badge badge-secondary">the release of Letraset sheets cont</span>
                        </div>
                    </div>
                </div>
       <!--end of .container-->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>