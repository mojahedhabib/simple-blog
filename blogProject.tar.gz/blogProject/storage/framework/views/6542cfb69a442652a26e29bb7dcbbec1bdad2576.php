<?php $__env->startSection('title', "|Edit Tag"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h2 class="card-title">Edit Tag</h2>
                <form action="<?php echo e(route('tags.update', $tags->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <label for="name"></label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($tags->name); ?>">
                    <input type="submit" value="Save Changes" class="btn btn-primary" style="margin-top: 15px;">
                </form>
            </div>
        </div>
    </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>