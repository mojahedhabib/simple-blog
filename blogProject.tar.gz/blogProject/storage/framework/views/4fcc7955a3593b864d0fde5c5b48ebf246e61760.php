<?php $__env->startSection('title', '| All Tags'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 mt-5">
            <div class="card">
                <div class="card-body">
                    <h1 class="card-title">Tags</h1>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($tag->id); ?></th>
                                    <td><a href="<?php echo e(route('tags.show', $tag->id)); ?>" style="color: black; text-decoration: none;"><?php echo e($tag->name); ?></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-3 mt-5">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('tags.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <h2 class="card-title">New Tag</h2>
                        <input type="text" class="form-control" name="name" placeholder="Add New Tag">
                        <input type="submit" class="btn btn-success btn-h1-spacing btn-block" value="Submit ">
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>








<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>