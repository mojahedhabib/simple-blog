<?php $__env->startSection('title', "| Deleting Comment"); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h3>Delete this comment?</h3>
            <hr>
            <p>
                <strong><?php echo e($comment->name); ?></strong><br><br>
                <strong><?php echo e($comment->email); ?></strong><br><br>
                <strong><?php echo e($comment->comment); ?></strong><br><br>
            </p>
            <form class="delete" action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="POST" a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" class="btn btn-danger btn-block" value="Delete Comment">
            </form>
        </div>
    </div>

    <script>
        $("delete").on("submit", function() {
            return confirm("Do you want to delete this item?");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>