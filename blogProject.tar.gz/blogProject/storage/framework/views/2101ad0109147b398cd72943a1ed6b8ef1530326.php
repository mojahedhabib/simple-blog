<?php $__env->startSection('title', '| View Post'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <h1> <?php echo e($post['title']); ?></h1> <br>
        <p class="lead text-justify"><?php echo $post['body']; ?></p>
        <hr>
        <i class="fas fa-tags">Tags</i>
            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge badge-secondary"><?php echo e($tag->name); ?></span>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div id="backend-comments" style="marin-top: 50px;">
        <h3 style="margin-top: 10px;"><i class="fas fa-comment-dots">Comments</i><small><span class="badge badge-info"><?php echo e($post->comments()->count()); ?>  total</span></small></h3>

        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Comment</th>
                    <th width="70px"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($comment->name); ?></td>
                        <td><?php echo e($comment->email); ?></td>
                        <td><?php echo e($comment->comment); ?></td>
                        <td>
                            <a href="<?php echo e(route('comments.edit', [$comment->id, 'edit'])); ?>" class="btn btn-sm btn-primary"><span class="far fa-edit"></span></a>
                            <a href="<?php echo e(route('comments.delete', [$comment->id, 'delete'])); ?>" class="btn btn-sm btn-danger"><span class="far fa-trash-alt"></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>

    <div class="col-md-4">
        <div class="card text-justify">
            <div class="card-body">

                <div class="col col-md-12">
                    <div class="row offset-md-1">
                        <dt class="card-title">URL: &nbsp;</dt>
                        <dd  class="card-text"> <a href="<?php echo e(route('blog.single', array($post->id))); ?>"><?php echo e(url($post->id)); ?></a></dd>
                    </div>
                </div>

                <div class="col col-md-12">
                    <div class="row offset-md-1">
                        <dt class="card-title">Category: &nbsp;</dt>
                        <dd  class="card-text"> <?php echo e($post->category->name); ?></dd>
                    </div>
                </div>

                <div class="col col-md-12">
                    <div class="row offset-md-1">
                        <dt class="card-title">Created At: &nbsp;</dt>
                        <dd  class="card-text"> <?php echo e(date('M j, Y h:ia', strtotime($post['created_at']))); ?></dd>
                    </div>
                </div>

                <div class="col col-md-12">
                     <div class="row offset-md-1">
                        <dt class="card-title">last Updated: &nbsp;</dt>
                        <dd class="card-text mb-0"><?php echo e(date('M j, Y h:ia', strtotime($post['updated_at']))); ?></dd>
                     </div>
                </div>
                <hr>
                <div class="col col-md-12 text-center">
                    <div class="row">
                        <div class="col-md-6" style="margin:0px; background-position: center center">
                            <form action="<?php echo e(route('post.edit', [$post->id, 'edit'])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('GET'); ?>
                                <input type="submit" class=" btn btn-block btn-primary" value="Edit">
                            </form>
                        </div>
                        <div class="col-md-6">
                            <form action="<?php echo e(route('post.destroy', [$post->id])); ?>" method="post">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Delete" class="btn btn-danger btn-block" style="background-position: center">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col col-md-12" style="margin-top: 5px; margin-bottom: 5px;">
                    <a href="<?php echo e(route('post.index', [])); ?>" methods="GET"> <button class=" btn  btn-primary btn-block"><< See All Posts</button> </a>
                </div>
            </div>
        </div> <!--end of col-md-4-->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>