<?php $__env->startSection('title', '|Edit Comment'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit Comment</h1>
    <hr style="margin-bottom: 30px;">

    <form action="<?php echo e(route('comments.update', $comment->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($comment->name); ?>" disabled >
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo e($comment->email); ?>" disabled>
        </div>
        <div class="form-group">
            <label for="comment">Comment</label>
            <textarea name="comment" id="comment" cols="30" rows="10" class="form-control"><?php echo e($comment->comment); ?></textarea>
        </div>
        <input type="submit" class="btn btn-success btn-block" style="margin-top: 15px;" value="Save Changes">
    </form>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>